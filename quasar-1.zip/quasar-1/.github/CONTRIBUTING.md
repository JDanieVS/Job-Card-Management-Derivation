# Quasar Contributing Guide

The guide can be found [here](../CONTRIBUTING.md).
