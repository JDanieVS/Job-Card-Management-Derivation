---
name: Docs report (Quasar v2)
about: Create a report to help us improve Quasar v2 docs
title: ''
labels: ":page_facing_up: docs, \U0001F51D Qv2"
assignees: ''

---


