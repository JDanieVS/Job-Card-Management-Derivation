<template>
  <div class="q-pa-md q-gutter-md">
    <div>
      <q-chip size="18px" icon="bookmark">
        Bookmark
      </q-chip>
    </div>

    <div>
      <q-chip size="xs" icon="bookmark">
        Bookmark
      </q-chip>

      <q-chip size="sm" icon="bookmark">
        Bookmark
      </q-chip>

      <q-chip size="md" icon="bookmark">
        Bookmark
      </q-chip>

      <q-chip size="lg" icon="bookmark">
        Bookmark
      </q-chip>

      <q-chip size="xl" icon="bookmark">
        Bookmark
      </q-chip>
    </div>

    <div>
      <q-chip dense size="xs" icon="bookmark">
        Bookmark
      </q-chip>

      <q-chip dense size="sm" icon="bookmark">
        Bookmark
      </q-chip>

      <q-chip dense size="md" icon="bookmark">
        Bookmark
      </q-chip>

      <q-chip dense size="lg" icon="bookmark">
        Bookmark
      </q-chip>

      <q-chip dense size="xl" icon="bookmark">
        Bookmark
      </q-chip>
    </div>
  </div>
</template>
