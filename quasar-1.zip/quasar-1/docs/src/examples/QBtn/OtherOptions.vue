<template>
  <div class="q-pa-md">
    <q-btn color="black" class="full-width" label="Full-width" />

    <q-btn color="primary" label="With Tooltip" class="q-mt-md">
      <q-tooltip content-class="bg-accent">I'm a tooltip</q-tooltip>
    </q-btn>
  </div>
</template>
