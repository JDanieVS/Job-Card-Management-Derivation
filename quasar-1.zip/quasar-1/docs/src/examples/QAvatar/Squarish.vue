<template>
  <div class="q-pa-md q-gutter-sm">
    <q-avatar size="32px" font-size="26px" color="primary" text-color="grey-4" square>
      <span>D</span>
    </q-avatar>
    <q-avatar size="32px" color="teal" text-color="grey-4" icon="wifi" rounded />
  </div>
</template>
