<template>
  <div class="q-pa-md">
    <div class="q-gutter-sm">
      <q-checkbox v-model="val" />
    </div>

    <div class="q-px-sm">
    </div>
  </div>
</template>

<script>
export default {
  data () {
    return {
      val: true
    }
  }
}
</script>
