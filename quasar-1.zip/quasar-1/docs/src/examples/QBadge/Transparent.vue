<template>
  <div class="q-pa-md q-gutter-md">
    <q-btn color="teal" size="sm" label="Unread Mails">
      <q-badge color="orange" floating transparent>
        ∞
      </q-badge>
    </q-btn>

    <q-btn dense round flat icon="email">
      <q-badge color="red" floating transparent>
        4
      </q-badge>
    </q-btn>

    <div class="text-h4">
      Title
      <q-badge transparent align="middle" color="orange">
        app v1.0.0
      </q-badge>
    </div>
  </div>
</template>
