<template>
  <div class="q-pa-md q-gutter-md">
    <q-badge outline color="primary" label="Outline" />
    <q-badge outline color="orange" label="Outline" />
    <q-badge outline color="secondary" label="Outline" />

    <div class="text-h4">
      Text
      <q-badge outline align="middle" color="teal">
        v1.0.0
      </q-badge>
    </div>
  </div>
</template>
