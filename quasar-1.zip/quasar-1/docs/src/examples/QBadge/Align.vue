<template>
  <div class="q-pa-md q-gutter-sm">
    <div class="text-h4">
      Title
      <q-badge align="top">cli v1.0.0</q-badge>
    </div>

    <q-separator />

    <div class="text-h4">
      Title
      <q-badge align="middle">app v1.0.0</q-badge>
    </div>

    <q-separator />

    <div class="text-h4">
      Title
      <q-badge align="bottom">docs v1.0.0</q-badge>
    </div>
  </div>
</template>
