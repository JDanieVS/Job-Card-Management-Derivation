<template>
  <q-page padding>
    <!-- content -->
  </q-page>
</template>

<script lang="ts">
import Vue from 'vue'
export default Vue.extend({
  // name: 'PageName'
})
</script>
